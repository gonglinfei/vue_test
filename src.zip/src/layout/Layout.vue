<template>
    <el-container class="container">
        <el-container>
            <el-header>
                <el-row :gutter="20">
                    <el-col :span="12">
                        <HeadMenu></HeadMenu>
                    </el-col>
                    <el-col class="header-menu" :span="12">
                        <HeadMenu></HeadMenu>
                    </el-col>
                </el-row>
            </el-header>
            <el-main :style="defaultHeight">
                <router-view/>
            </el-main>
        </el-container>
        <el-backtop target=".el-main"></el-backtop>
    </el-container>
</template>

<script>
    import {onBeforeMount, reactive, toRefs} from 'vue'
    import {useRouter} from 'vue-router'
    import HeadMenu from "@/components/HeadMenu"

    export default {
        components:{
            HeadMenu
        },
        setup() {
            const router = useRouter()
            const state = reactive({
                logo: require('@/assets/image/logo.png'),
                isCollapse: false,
                asideWidth: '220px',
                defaultHeight: {
                    height: ''
                },
                routers: [],
            })

            onBeforeMount(() => {
                state.routers = router.options.routes
                state.defaultHeight.height = document.body.clientHeight + "px"
            })

            const onCollapse = () => {
                if (state.isCollapse) {
                    state.asideWidth = '220px'
                    state.isCollapse = false
                } else {
                    state.isCollapse = true
                    state.asideWidth = '64px'
                }
            }

            const onRefresh = () => {
                router.push({ path: 'main'})
            }

            return {
                ...toRefs(state),
                onCollapse,
                onRefresh
            }
        }
    }
</script>
<style lang="less">
    .container{
        background: rgb(245, 247, 249);
        .el-aside{
            height: 100%;
            transition: all .5s;
            background-color: #001529;
            overflow-y: auto;
            overflow-x: hidden;

            .aside-logo{
                height: 59px;
                color: white;
                cursor: pointer;
                border-bottom: 1px #cccccc solid;
                .logo-image {
                    width: 40px;
                    height: 40px;
                    top: 12px;
                    padding-left: 12px;
                }
                .logo-name{
                    font-size: 20px;
                    font-weight: bold;
                    padding: 2px;
                }
            }
            .aside-menu:not(.el-menu--collapse) {
                width: 220px;
                .el-menu-item.is-active {
                    background-color: #D9393B !important;
                }
            }

            .is-collapse {
                display: none;
            }
        }

        .el-aside::-webkit-scrollbar{
            width: 0px;
        }

        .el-header{
            background: white;
            line-height: 60px;
            font-size: 24px;
            border-bottom: 1px #cccccc solid;
            .header-collapse{
                cursor: pointer;
            }
            .header-breadcrumb{
                padding-top: 0.9em;
            }
            .header-menu{
                text-align: right;
            }
        }
        .el-main{
            padding: 0.6em;
            overflow-x: hidden;
            overflow-y: auto;
        }
        .el-main::-webkit-scrollbar{
            width: 0px;
        }
    }
</style>