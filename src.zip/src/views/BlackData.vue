<template>
    <div class="goods-list">
        <el-card shadow="never">
            <template #header>
                <div class="clearfix">
                    <el-image class="icon" :src="require('@/assets/image/icon/list.png')"/>
                    <span>数据列表</span>
                </div>
            </template>
            <div class="content">
                <div class="content-header">
                    <el-row :gutter="20">
                        <el-col :span="4">
                            <el-input v-model="keyword" placeholder="请输入设备IP"></el-input>
                        </el-col>
                        <el-col :span="4">
                            <el-select v-model="typeVal" filterable placeholder="请选择" v-if="types.length == 2">
                                <el-option v-for="item in types" :key="item.value" :label="item.label" :value="item.value"/>
                            </el-select>
                        </el-col>
                        <el-col :span="6">
                            <el-button type="primary" @click="getUser">获取数据</el-button>
                            <el-button type="danger" @click="setDataInfo">设置数据</el-button>
                        </el-col>
                    </el-row>
                </div>
                <div class="content-main">
                    <el-row :gutter="20">
                        <el-col :span="12">
                            <el-table :data="pageFirstTableData()" border stripe style="width: 100%; margin: 1em 0"
                        v-loading="loading"
                        element-loading-text="拼命加载中..."
                        element-loading-spinner="el-icon-loading"
                        element-loading-background="rgba(0, 0, 0, 0.8)"
                        :style="{ height: tableHeight + 'px' }"
                        @cell-click="handleCellClick">
                        <el-table-column type="selection" width="55" align="center"></el-table-column>
                        <el-table-column
                        v-for="(column, index) in columns"
                        :key="index"
                        :prop="column.prop"
                        :label="column.label">
                            <template class="item" #default="{ row }">
                                <el-input class="item__input" v-if="isEditing(row, column)" 
                                v-model="row[column.prop]" placeholder="请输入内容"
                                @blur="stopEditing(row, column)"
                                @keyup.enter="stopEditing(row, column)" size="small"
                                @mousedown.prevent
                                v-focus
                                v-clickoutside="cancelInput"></el-input>
                                <div class="item__txt" v-else @click="handleCellClick(row, column)">{{row[column.prop]}}</div>
                            </template>
                        </el-table-column>
                        <el-table-column label="操作" align="center" width="210">
                                <el-button size="small" round @click="setDataInfo">设置</el-button>
                                <el-button type="danger" size="small" round @click="delDataInfo">删除</el-button>
                        </el-table-column>
                        </el-table>
                        </el-col>
                        <el-col :span="12">
                            <el-table :data="pageSecondTableData()" border stripe style="width: 100%; margin: 1em 0"
                        v-loading="loading"
                        element-loading-text="拼命加载中..."
                        element-loading-spinner="el-icon-loading"
                        element-loading-background="rgba(0, 0, 0, 0.8)"
                        :style="{ height: tableHeight + 'px' }"
                        @cell-click="handleCellClick">
                        <el-table-column type="selection" width="55" align="center"></el-table-column>
                        <el-table-column
                        v-for="(column, index) in columns"
                        :key="index"
                        :prop="column.prop"
                        :label="column.label">
                            <template class="item" #default="{ row }">
                                <el-input class="item__input" v-if="isEditing(row, column)" 
                                v-model="row[column.prop]" placeholder="请输入内容"
                                @blur="stopEditing(row, column)"
                                @keyup.enter="stopEditing(row, column)" size="small"
                                @mousedown.prevent
                                v-focus
                                v-clickoutside="cancelInput"></el-input>
                                <div class="item__txt" v-else @click="handleCellClick(row, column)">{{row[column.prop]}}</div>
                            </template>
                        </el-table-column>
                        <el-table-column label="操作" align="center" width="210">
                                <el-button size="small" round @click="setDataInfo">设置</el-button>
                                <el-button type="danger" size="small" round @click="delDataInfo">删除</el-button>
                        </el-table-column>
                        </el-table>
                        </el-col>
                    </el-row>
                    <el-pagination @size-change="sizeChange" @current-change="currentChange"
                                   layout="total, sizes, prev, pager, next, jumper"
                                   :current-page="currentPage"
                                   :page-sizes="pageSizes"
                                   :page-size="pageSize"
                                   :total="total"/>
                </div>
            </div>
        </el-card>
    </div>
</template>

<script>
    import {onMounted, reactive, toRefs} from 'vue'
    import {ElMessageBox, ElNotification} from 'element-plus'
    import {getUserInfo, setUserInfo, setIpAddress} from '@/axios/api'

    const clickoutside = {
        // 初始化指令
        bind(el, binding) {
            function documentHandler(e) {
            // 这里判断点击的元素是否是本身，是本身，则返回
            if (el.contains(e.target)) {
                return false;
            }
            // 判断指令中是否绑定了函数
            if (binding.expression) {
                // 如果绑定了函数 则调用那个函数，此处binding.value就是handleClose方法
                binding.value(e);
            }
            }
            // 给当前元素绑定个私有变量，方便在unbind中可以解除事件监听
            el.__vueClickOutside__ = documentHandler;
            document.addEventListener('click', documentHandler);
        },
        update() {},
        unbind(el) {
            // 解除事件监听
            document.removeEventListener('click', el.__vueClickOutside__);
            delete el.__vueClickOutside__;
        },
    };
    export default {
        directives: {
            //注册一个局部的自定义指令 v-focus
            focus: {
                mounted(el) {
                    console.log(el.children[0].children[0]);
                    el.children[0].children[0].focus();
                    //因为el-input这是个组件，input外面被一层 div 包裹着,
                    ///el打印出来是外面这个 div，需要找到内层的input
                },
            },

            clickoutside
        },

        setup() {
            const state = reactive({
                keyword: '',
                types: [],
                typeVal: '',
                loading: true,
                tableData: [],
                currentPage: 1,
                pageSizes: [10, 20, 50, 100],
                pageSize: 10,
                total: 100,
                tableHeight : 100,
                editProp : ['loadPw', 'solarPw'],
                columns: [
                    { label: '时间', prop: 'date' },
                    { label: '光伏功率', prop: 'solarPw' },
                    { label: '负载功率', prop: 'loadPw' },
                    { label: '功率差值', prop: 'pwResult'}
                ],
                clickCellMap : {},
                editingCell : null,
                isEdit: false,
            })

            onMounted(() => {
                window.addEventListener('resize', updateTableHeight);
                state.types = [
                    {value: '1', label: '黄金糕'},
                    {value: '2', label: '双皮奶'}
                ]
                console.log(state.types);
                init()
            })

            const getUser = async () => {
                try {
                    if (state.keyword && state.keyword != '')
                    {
                        const keyip = state.keyword + ':80'
                        setIpAddress(keyip);
                    }
                    
                    let res = await getUserInfo({ id: 2 });
                    console.log(res.result[0], '/api', '获取的用户信息');
                    // state.tableData = res.data; // 更新响应式变量
                    state.tableData = res.result;
                    state.total = res.result.length;
                    state.tableHeight = (state.total > 25 ? 25 : state.total) * 30;
                    state.pageSize = state.total;
                } catch (error) {
                    console.error('获取用户信息失败:', error);
                }
            }

            //前端限制分页（tableData为当前展示页表格）
            const pageFirstTableData = () => {
                const start = 0;
                const end = state.pageSize / 2;
                return state.tableData.slice(start, end);
            };

            const pageSecondTableData = () => {
                const start = state.pageSize / 2;
                const end = state.total;
                return state.tableData.slice(start, end);
            };

            const updateTableHeight = () => {
                state.tableHeight = window.innerHeight - 200;
            };

            // const beforeDestroy = () => {
            //     window.removeEventListener('resize', updateTableHeight); // 清理事件监听
            // },

            // 初始化数据
            const init = () =>{
                let keyword = state.keyword
                if(keyword == null || keyword == ''){
                    keyword = null
                }

                let typeVal = state.typeVal
                if(typeVal == null || typeVal == 0){
                    typeVal = null
                }
                console.log("keyword:"+keyword+",typeVal:"+typeVal)
                console.log("currentPage:"+state.currentPage+",pageSize:"+state.pageSize)

                state.loading = false
                document.body.style.overflow = 'auto';
            }

            const setData = async (jsonData) => {
                try {
                    let setRes = await setUserInfo(jsonData);
                    console.log(setRes.result, '/api', '设置成功');
                } catch (error) {
                    console.error('设置信息失败:', error);
                }
            }
                 

            // 设置
            const setDataInfo = () => {
                const jsonData = JSON.stringify(state.tableData)
                const jsonObj = "{\"result\":" + jsonData + "}";
                console.log(state.tableData)
                setData(jsonObj)
            }

            // 删除
            const delDataInfo = () =>{
                ElMessageBox.confirm('此操作将永久删除该条数据, 是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning',
                    callback: action =>{
                        if('confirm' == action){
                            console.log("提交：")
                            init()
                            ElNotification({
                                title: '成功',
                                message: '删除成功！',
                                duration: 2000,
                                type: 'success'
                            })
                        }
                    }
                })
            }

            const sizeChange = (val) => {
                state.pageSize = val
            }

            const currentChange = (val) => {
                state.currentPage = val
            }

            /** 点击cell */
            const handleCellClick = (row, column) => {
                if (state.editingCell && state.editingCell.row === row && state.editingCell.property === column.prop)
                {
                    return;
                }

                const property = column.prop
                state.editingCell = { row, property };
                if (state.editProp.includes(property)) {
                    console.log(`Mouse entered cell: ${row[property]}`);
                }
            }

            /** 取消编辑状态 */
            const cancelEditable = (cell) => {
                state.isEdit = false
                console.log(`Mouse entered cell: ${cell.name}`);
            }

            const stopEditing = (row, column) => {
                const loadPw = column.prop
                if (state.clickCellMap[loadPw] !== undefined) {
                    if (!state.clickCellMap[loadPw].includes(row[loadPw])) {
                        state.clickCellMap[loadPw].push(row[loadPw])
                    }
                } else {
                    state.clickCellMap[loadPw] = [row[loadPw]]
                }

                if (state.editProp.includes(column.prop))
                {
                    row[column.prop] = Number(row[column.prop])
                }
            }

            const isEditing = (row, column) => {
                return state.editingCell && state.editingCell.row === row && state.editingCell.property === column.prop;
            }

            /** 保存数据 */
            const save = (row) => {
                const id = row.id
                // 取消本行所有cell的编辑状态
                state.clickCellMap[id].forEach(cell => {
                    state.cancelEditable(cell)
                })
                state.clickCellMap[id] = []
            }

            const cancelInput = () => {
                state.editingCell = {};
            }

            return {
                ...toRefs(state),
                init,
                setDataInfo,
                delDataInfo,
                sizeChange,
                currentChange,
                getUser,
                pageFirstTableData,
                pageSecondTableData,
                handleCellClick,
                cancelEditable,
                save,
                stopEditing,
                isEditing,
                cancelInput
            }
        }
    }
</script>

<style lang="less">
    @import '../common/style/common';

    .goods-list {
        .content-main{
            .table-image{
                width: 45px;
                height: 45px;
            }
        }
    }
</style>