<template>
    <div>商户分析</div>
</template>

<script>
    export default {
        name: "MerchantAnalysis"
    }
</script>

<style scoped>

</style>