import { setBaseURL } from './index'
import request from './index'
 
//获取用户信息接口
let getUserInfostr = request.defaults.baseURL + '/getUserInfo'
let setUserInfostr = request.defaults.baseURL + '/setUserInfo'

export const getUserInfo = (data) => request.get('/getUserInfo', { params: data })

export const getUser = () => request.get('/getUser', { })

// 发送 POST 请求
export const setUserInfo = (jsonData) => request.post('/setUserInfo', jsonData, {
    headers: {
      'Content-Type': 'application/json' // 设置请求头为 JSON
    }
  })
  .then(response => {
    console.log('成功:', response);
    return response;
  })
  .catch(error => {
    console.error('错误:', error);
  })

export const setIpAddress = (ip) => {
    const ipstr = 'http://' + ip
    setBaseURL(ipstr);
    getUserInfostr = request.defaults.baseURL + '/getUserInfo'
    setUserInfostr = request.defaults.baseURL + '/setUserInfo'
}