import Axios from 'axios'

// axiosInstance.js
let currentBaseURL = 'http://192.168.17.56:80';
// let currentBaseURL = '/api';
const instance = Axios.create({
	baseURL: currentBaseURL
})
 
instance.interceptors.request.use((config) => {
	console.log(config, '发送请求前config信息')
	return config
}, err => {
	return Promise.reject(err)
})
 
instance.interceptors.response.use((res) => {
	console.log('接受的数据')
	return res.data
}, err => {
	return Promise.reject(err)
})

const setBaseURL = (newBaseURL) => {
  currentBaseURL = newBaseURL;
  instance.defaults.baseURL = currentBaseURL; // 更新 Axios 实例的 baseURL
};

export { setBaseURL }
 
export default instance