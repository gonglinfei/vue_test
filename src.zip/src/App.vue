<template>
    <router-view></router-view>
</template>

<script>
</script>

<style>
    html, body {
        width: 100%;
        height: 100%;
        padding: 0;
        margin: 0;
        overflow: auto;
        font-family: Avenir, Helvetica, Arial, sans-serif;
    }
    #nprogress .bar {
        /*自定义进度条颜色*/
        background: #D9393B !important;
    }
</style>
